const selenium = require('selenium-webdriver');
const firefox = require('selenium-webdriver/chrome');
const elements = require('./page-elements.js');
const fspath = require('path');
const fs = require('fs');

const { By, Key } = selenium;

const clipboardy = require('clipboardy');


const FB_LOGIN_URL = 'https://m.facebook.com';

//#region WebTools
var __browser;

const document = {
    /**
     * Finds an element by Css selector
     * @param {String} selector 
     * @returns {import('selenium-webdriver').WebElementPromise}
     */
    querySelector: function (selector) {
        return __browser.findElement(By.css(selector));
    }
}

function sleep(ms) {
    return new Promise((resolve) => {
        setTimeout(resolve, ms);
    });
}

function awaitUrlChange(page, url) {
    return new Promise((resolve) => {
        while (!page.url == url);
        resolve();
    });
}

async function pageLoad() {
    return __browser.wait(function () {
        return __browser.executeScript('return document.readyState').then(function (readyState) {
            return readyState === 'complete';
        });
    });
}

function webType(element, text, directType) {
    webClick(element);
    if (directType == undefined)
        directType = false;

    if (directType === true) {
        let el = document.querySelector(element);
        return el.sendKeys(text);
    }

    let clip = clipboardy.readSync();
    clipboardy.writeSync(text);
    return new Promise((resolve) => {
        document.querySelector(element).sendKeys(Key.CONTROL, 'v')
            .then(() => {
                clipboardy.writeSync(clip);
                resolve();
            });
    });

}

function webClick(element, js) {
    if (js) {
        let code = 'document.querySelector(\''+element+'\').click();';
        console.log('code', code);
        return __browser.executeScript(code);
    }
    return document.querySelector(element).click();
}

//#endregion WebTools

class Facebook {
    constructor(email, password, bornDate) {
        this.email = email;
        this.password = password;
        this.bornDate = bornDate;
    }

    /**
     * 
     * Login to Facebook with email and password
     * 
     * @param {import('selenium-webdriver').ThenableWebDriver} browser
     * The selenium browser to load and log into Facebook
     */
    async login(browser, console) {
        __browser = browser;

        await browser.get(FB_LOGIN_URL);

        await sleep(1000);

        try {
        var element = document.querySelector(elements.FB_ENTRAR);
        if ((await element).getText() == 'Entrar')
            (await element).click();
        }
        catch {}

        await sleep(1000);

        await webType(elements.FB_LOGIN_EMAIL, this.email);

        await sleep(1000);

        await webType(elements.FB_LOGIN_PASSWORD, this.password);

        await sleep(1000);

        await webClick(elements.FB_LOGIN_SUBMIT);

        await sleep(4000);

        var gotCheckpoint = (await browser.getCurrentUrl()).includes('/checkpoint');

        console.log('gotckeckpoint?', gotCheckpoint, this.bornDate);

        if (this.bornDate == null) while (gotCheckpoint) await sleep(500);
        else if (gotCheckpoint) {
            console.log('\n  >>> Got checkpoint\n');
            await sleep(3000);
            await webClick(elements.FB_CHECKPOINT_CONTINUE);
            await sleep(4000);
            await webClick(elements.FB_CHECKPOINT_BORN_DATE, true);
            await sleep(4000);
            await webClick(elements.FB_CHECKPOINT_CONTINUE);
            await sleep(4000);
            var split = this.bornDate.split('/');
            console.log(split);
            await webClick(elements.FB_CHECKPOINT_DAY.replace('{X}', split[0]), true);
            await sleep(4000);

            let _bornMonth = split[1];
            if (_bornMonth[0] == '0')
                _bornMonth = _bornMonth.substring(1);

            await webClick(elements.FB_CHECKPOINT_MONTH.replace('{X}', _bornMonth), true);

            await sleep(3000);
            await webClick(elements.FB_CHECKPOINT_YEAR.replace('{X}', split[2]), true);
            await sleep(3000);
            await webClick(elements.FB_CHECKPOINT_CONTINUE);
            await sleep(5000);
            await webClick(elements.FB_CHECKPOINT_CONTINUE);
            await sleep(1000);
        }

        while (await browser.getTitle() != 'Facebook')
        await sleep(1000);
    }

    /**
     * 
     * @param {import('selenium-webdriver').ThenableWebDriver} browser 
     * @param {import('./ad.js')} ad 
     * @param {Number} totalGroups 
     * @param {Number} groupsStartOffset 
     * @param {String} groupUrl 
     */
    async publishAd(browser, ad, totalGroups, groupsStartOffset, groupUrl, console) {
        __browser = browser;

        console.log('Started');

        groupUrl = groupUrl.replace('www.facebook.com', 'm.facebook.com');
        // Loads mobile Facebook

        await browser.get(groupUrl);
        await sleep(1000);

        await pageLoad();

        await sleep(3000);
        await webClick(elements.FB_SELL_ITEM);
        await sleep(3000);

        var dataToFill = {
            AD_TITLE: ad.name,
            AD_PRICE: ad.price,
            AD_DESCRIPTION: ad.description,
            AD_LOCATION: ad.location
        }

        var keys = Object.keys(dataToFill);
        for (var i = 0; i < keys.length; i++) {
            var elementKey = keys[i];
            var elementSelector = elements['FB_' + elementKey];
            await webType(elementSelector, (dataToFill[elementKey] + ''), elementKey == 'AD_PRICE');
            await sleep(2000);
        }

        await sleep(2000);

        var pic_grp = ad.pics[ad.pictureGroup];

        for (var i = 0; i < pic_grp.length; i++) {
            var picture = pic_grp[i];
            var path;
            if (!fs.existsSync(picture))
                path = fspath.join(__dirname, ad.defaultSaveDirectory(), picture);
            else 
                path = picture;

            console.log(path);

            await sleep(1000);
            await webType(elements.FB_AD_IMG_UPLOAD,
                path, true);
            await sleep(1000);
        }

        ad.pictureGroup++;
        if (ad.pictureGroup >= ad.pics.length)
            ad.pictureGroup = 0;
        ad.save();

        await sleep(1000);

        // Wait picture(s) upload

        var element = document.querySelector(elements.FB_AD_PUBLISH);
        var disabled = await element.getAttribute('disabled');
        while (disabled) {
            await sleep(1000);
            disabled = await element.getAttribute('disabled');
        }

        await webClick(elements.FB_AD_PUBLISH);
        await sleep(3000);
        try {
            await webClick(elements.FB_AD_PUBLISH_AS_SELL);
        }
        catch {}

        await sleep(10000);

        await webClick(elements.FB_AD_MORE_GROUPS, true);
        await sleep(7000);


        for (let i = 0; i < totalGroups; i ++) {
            try {
                await browser.executeScript(
                `document.querySelectorAll('${elements.FB_AD_GROUP_CHECK}')[${groupsStartOffset + i}].click();`);
            }
            catch {
                try {
                    await browser.executeScript(
                        `document.querySelectorAll('${elements.FB_AD_GROUP_CHECK}')[${i}].click();`);
                }
                catch {
                    console.error(`Não foi possível marcar o grupo ${i}`);
                }
            }
            await sleep(500);
        }

        await webClick(elements.FB_AD_MORE_GROUPS_PUBLISH, true);
        await sleep(2000);

        console.log('Anúncio finalizado');
    }
}

module.exports = Facebook;