# facebook.py
import time
import pyperclip
import os
from textutil import *
from fbelements import *

class Facebook:
    def __init__(self, browser, keys):
        self.browser = browser
        self.Keys = keys
        self.browser.get('https://mbasic.facebook.com/')
        self.Focus()

    def ActionElement(self, selector, action):
        self.browser.execute_script('try{document.querySelector("' + selector + '").' + action + '}catch{ }')

    def Login(self, email, password):
        print('Fazendo Log-In ...', email)
        
        emailSelector = LOGIN_EMAIL
        passwordSelector = LOGIN_PASSWORD
        enterSelector = LOGIN_ENTER

        while True:
            try:
                self.browser.find_element_by_css_selector(emailSelector)
                self.browser.find_element_by_css_selector(passwordSelector)
                enterBtn = self.browser.find_element_by_css_selector(enterSelector)

                self.ActionElement(emailSelector, 'value="' + email + '"')
                self.ActionElement(passwordSelector, 'value="' + password + '"')
                enterBtn.click()
                time.sleep(15)
                break
            except:
                print("Error")
                self.browser.refresh()
                self.browser.get('about:blank')
                self.browser.get('https://mbasic.facebook.com/')
                time.sleep(15)
                if not 'Log In' in self.browser.title and 'Facebook' in self.browser.title:
                    break

        said = False
        print(self.browser.current_url)
        while '/checkpoint' in self.browser.current_url:
            if said == False:
                ERR('BLOCKED_CHECKPOINT')
                said = True
            time.sleep(1)

    def ClickElement(self, selector):
        self.ActionElement(selector, 'click()')

    def Focus(self):
        window_after = self.browser.window_handles[0]
        self.browser.switch_to.window(window_after)
        self.browser.execute_script('window.focus()')

    def EnterText(self, txt, elementSelector, enter=False):
        oldTxt = pyperclip.paste()
        pyperclip.copy(txt)

        element = self.browser.find_element_by_css_selector(elementSelector)
        try:
            element.click()
        except:
            try:
                ClickElement(elementSelector)
            except:
                abc = '123'
        
        element.send_keys(self.Keys.CONTROL + 'a')
        element.send_keys(self.Keys.CONTROL + 'v')

        if enter == True:
            element.send_keys(self.Keys.RETURN)

        pyperclip.copy(oldTxt)

    def DoAd(self, product, description, price, location, images, groups, confirm):

        offline_reported = False
        while 'Problem loading page' in self.browser.title or 'Server Not Found' in self.browser.title:
            if offline_reported == False:
                ERR('OFFLINE_ERR')
                offline_reported = True
                
            time.sleep(15)

        self.ActionElement(ITEM_TITLE, 'click()')
        time.sleep(7)

        self.ActionElement(ITEM_TITLE, 'click()')
        self.EnterText(product, ITEM_TITLE)

        time.sleep(1)

        self.EnterText(price, ITEM_PRICE)

        time.sleep(1)

        self.EnterText(location, ITEM_LOCATION)
        time.sleep(1)

        self.EnterText(description, ITEM_DESCRIPTION)

        time.sleep(1)
    

        for img in images:
            self.browser.find_element_by_css_selector(ITEM_PICTURES).send_keys(img)
            time.sleep(0.5)

        while True:
            try:
                self.browser.find_element_by_css_selector(PICTURE_LOADING_1) #1 LOADING element
                continue
            except:
                break

        while True:
            try:
                self.browser.find_element_by_css_selector(PICTURE_LOADING_2) #2 LOADING element
                continue
            except:
                break
        
        while True:
            try:
                self.browser.find_element_by_css_selector(PICTURE_LOADING_3) #3 LOADING element
                continue
            except:
                break

        time.sleep(2)

        INFO('Image OK')

        self.ClickElement(ITEM_CONTINUE)

        time.sleep(2.5)

        for i in range(groups):
            try:
                self.ClickElement(ITEM_GROUP_CHECK)
                time.sleep(0.35)
            except:
                time.sleep(1)
        
        self.ClickElement(ITEM_CONTINUE)
