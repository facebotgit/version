# ad.py

import os
import io
import time

class AdBuilder:
    def InvokeAd(self, adPath, invokef, totalGroups, confirm):
        f = io.open(adPath + 'inf.txt', mode='r', encoding='utf-8')
        content = f.read()
        f.close()
        config = content.split('\n')

        title = config[0]
        price = config[1]

        location = 'Novo Hamburgo'

        if len(config) > 2:
            location = config[2]

        print('AD:' + title)

        f = io.open(adPath + 'AD.txt', mode='r', encoding='utf-8')
        descr = f.read()
        f.close()

        pics = []

        files = os.listdir(adPath)
        for file in files:
            if '.jpeg' in file:
                pics.append(adPath + file)
            elif '.png' in file:
                pics.append(adPath + file)
            elif '.jpg' in file:
                pics.append(adPath + file)

        # print (title, descr, price, pics)
        time.sleep(4)
        invokef(title, descr, price, location, pics, totalGroups, confirm)