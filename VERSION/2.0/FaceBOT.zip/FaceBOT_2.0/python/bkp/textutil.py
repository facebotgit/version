# class Color:
#     def __init__(self, type):
#         self.Type = type

#     def Get(self, color):
#         return '{[' + self.Type + color + ']}'

# colors = Color('back')

def WARN(txt):
    print(txt)

def INFO(txt):
    print('[INFO] ' + txt)

def ERR(txt):
    print('[ERROR] ' + txt)

def SUCCESS(txt):
    print('[OK] ' + txt)