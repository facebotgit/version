from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from facebook import *
from ad import *
import os
import io
import sys
from textutil import *
from colorama import *
from selenium.webdriver.firefox.options import Options
import time

init()

VERSION = '3.0'

os.system('cls')
os.system('title FACEBOT')

print('->FACEBOT CORE<-\nVERSION: ' + VERSION + '\n\n') # Allows C# software to read STDOUT

adb = AdBuilder()
# ROOT, FACEBOOK EMAIL, FACEBOOK PASSWORD, A BRICK, GROUPS, RANGE(0-100000000), includeMarketplace
args = sys.argv[1].replace('"', '').split(',')

root = args[0]
facebookEmail = args[1]
facebookPassword = args[2]
startGroup = args[3]
totalGroups = int(args[4])
ad_range = args[5]
includeMarketplace = args[6]

browser = webdriver.Firefox()
# browser = webdriver.Firefox()

if (root[len(root)-1] != '\\'):
    root += '\\'

ads = os.listdir(root)

range_split = ad_range.split('-')
range_start = int(range_split[0])
range_end = int(range_split[1])

face = Facebook(browser, Keys)

def DetectMinimized():
    size = browser.get_window_size()
    if size['width'] < MIN_W:
        return True
    return False

def Maximize():
    browser.maximize_window()
    time.sleep(2)
    reported = False
    while DetectMinimized():
        if reported:
            time.sleep(2)
            continue
        ERR('BROWSER_MIN')
        reported = True

tryies = 0
while True:
    if tryies > 10:
        ERR('EXIT_NO_NET')
        browser.close()
        browser.quit()
        sys.exit()
    try:
        face.Login(facebookEmail, facebookPassword)
        browser.get(startGroup)
        break
    except:
        if tryies == 0:
            ERR('OFFLINE_ERR')
        tryies+=1
        time.sleep(10)

time.sleep(10)

totalAd = 0
sucAd = 0

force_quit = False


idx=0
for ad in ads:
    if not '_' in ad and (idx >= range_start and idx <= range_end):
        time.sleep(15)

        while True:
            loop_ct = 0
            exMsg = ''
            if loop_ct > 3:
                ERR('Um erro ocorreu. Próximo ...')
                print('EXCPT:'+exMsg)
                break

            try:
                adb.InvokeAd(root + ad + '\\', face.DoAd, totalGroups, includeMarketplace)
                time.sleep(15)
                SUCCESS('Anúncio realizado com sucesso!')

                browser.refresh()
                sucAd = sucAd + 1
                break
            except Exception as e:
                exMsg = str(e)
                print('EXCPT:'+exMsg)
                try:
                    browser.refresh()
                    Maximize()
                except:
                    force_quit = True
                    print('ERR_NO_BROWSER')
                    print('Crashed');
                    idx = 500000
                    break
                time.sleep(5)
                loop_ct+=1

        totalAd = totalAd+1

    if not '_' in ad:
        idx = idx+1

if force_quit == False:
    print()
    SUCCESS(str(sucAd) + ' de ' + str(totalAd) + ' anúncios foram realizados com sucesso. ('+ str(sucAd) + '/' + str(totalAd) + ')')
    print()

try:
    browser.close()
    time.sleep(2)
    browser.quit()
except: x=0
