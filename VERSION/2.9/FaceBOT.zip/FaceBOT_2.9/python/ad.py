# ad.py

import os
import io
import time

class AdBuilder:
    def InvokeAd(self, adPath, invokef, totalGroups, market):
        f = io.open(adPath + 'inf.txt', mode='r', encoding='utf-8')
        content = f.read()
        f.close()
        config = content.split('\n')

        picGruopF = None
        picGruop = '1'

        try:
            picGruopF = io.open(adPath + 'grp.cfg', mode='r', encoding='utf-8')
            picGruop = picGruopF.read();
        except:
            picGruopF = io.open(adPath + 'grp.cfg', mode='w+', encoding='utf-8')
            picGruopF.write('1')
            picGruop = '1'

        picGruopF.close()

        newPicGroup =  str((int(picGruop)+1))
        if (os.path.isdir(adPath + newPicGroup + '.group')):
            picGruopF = io.open(adPath + 'grp.cfg', mode='w+', encoding='utf-8')
            picGruopF.write(newPicGroup)
        else:
            newPicGroup = '1'
            picGruopF = io.open(adPath + 'grp.cfg', mode='w+', encoding='utf-8')
            picGruopF.write(newPicGroup)

        picGruopF.close()

        title = config[0]
        price = config[1]

        location = 'Novo Hamburgo'

        print('PICGRP: ' + picGruop)

        if len(config) > 2:
            location = config[2]

        print('AD:' + title)

        f = io.open(adPath + 'AD.txt', mode='r', encoding='utf-8')
        descr = f.read()
        f.close()

        pics = []

        picGroupPath = adPath + picGruop + '.group'

        files = os.listdir(picGroupPath)
        for file in files:
            if '.jpeg' in file:
                pics.append(picGroupPath + '\\' + file)
            elif '.png' in file:
                pics.append(picGroupPath + '\\' + file)
            elif '.jpg' in file:
                pics.append(picGroupPath + '\\' + file)

        # print (title, descr, price, pics)
        time.sleep(4)
        invokef(title, descr, price, location, pics, totalGroups, market)