# ad.py

import os
import io
import time
from log import *

class AdBuilder:

    def __init__(self):
        self.err = None

    def InvokeAd(self, adPath, invokef, totalGroups, market, adLog):
        self.err = None
        try:

            f = io.open(adPath + 'inf.txt', mode='r', encoding='utf-8')
            content = f.read()
            f.close()
            config = content.split('\n')

            picGruopF = None
            picGroup = '1'

            try:
                picGruopF = io.open(adPath + 'grp.cfg', mode='r', encoding='utf-8')
                picGroup = picGruopF.read();
            except:
                picGruopF = io.open(adPath + 'grp.cfg', mode='w+', encoding='utf-8')
                picGruopF.write('1')
                picGroup = '1'

            picGruopF.close()

            newPicGroup =  str((int(picGroup)+1))
            if (os.path.isdir(adPath + newPicGroup + '.group')):
                picGruopF = io.open(adPath + 'grp.cfg', mode='w+', encoding='utf-8')
                picGruopF.write(newPicGroup)
            else:
                newPicGroup = '1'
                picGruopF = io.open(adPath + 'grp.cfg', mode='w+', encoding='utf-8')
                picGruopF.write(newPicGroup)

            picGruopF.close()

            title = config[0]
            price = config[1]

            adLog = AdLog(title)

            location = 'Novo Hamburgo'

            print('PICGRP: ' + picGroup)

            if len(config) > 2:
                location = config[2]

            print('AD:' + title)

            #descr = ''

            #try:
            f = io.open(adPath + 'AD.txt', mode='r', encoding='utf-8')
            descr = f.read()
            f.close()
            #except Exception as e:
            #    print('Error while reading AD.txt: ' + str(e))
            #    descr = ''
                

            pics = []

            picGroupPath = adPath + picGroup + '.group'

            files = os.listdir(picGroupPath)
            for file in files:
                if '.jpeg' in file:
                    pics.append(picGroupPath + '\\' + file)
                elif '.png' in file:
                    pics.append(picGroupPath + '\\' + file)
                elif '.jpg' in file:
                    pics.append(picGroupPath + '\\' + file)


            
            adLog.SetImageGroup(picGroup)

            # print (title, descr, price, pics)
            time.sleep(4)
            return invokef(title, descr, price, location, pics, totalGroups, market, adLog)
        
        except Exception as e:
            self.err = e
            return adLog
