# fbelements

ITEM_TITLE = '._58al[placeholder=\'O que você está vendendo?\']'
ITEM_PRICE = 'input[placeholder=\'Preço\']'
ITEM_LOCATION = '._58al[placeholder=\'Adicionar localização (opcional)\']'
ITEM_LOCATION_2 = '._58al[placeholder=\'Adicionar localização\']'
ITEM_DESCRIPTION = 'div[aria-label=\'Descreva seu item (opcional)\']'
ITEM_DESCRIPTION_2 = 'div[aria-label=\'Descreva seu item (opcional)\']'
ITEM_PICTURES = 'input[type=file]'
ITEM_CONTINUE = 'button._1mf7._4jy0._4jy3._4jy1._51sy'
ITEM_GROUP_CHECK = 'div[aria-checked=false]._kx6'

PICTURE_LOADING_1 = '._50_c._1a__'
PICTURE_LOADING_2 = 'img._jfg'
PICTURE_LOADING_3 = 'img._1b00'

LOGIN_EMAIL = 'input[name=email]'
LOGIN_PASSWORD = 'input[type=password]'
LOGIN_ENTER = 'input[name=login]'