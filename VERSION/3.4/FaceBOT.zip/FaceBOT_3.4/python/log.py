class AdLog:
    def __init__(self, adName):
        self.adName = adName
        self.success = 'nao'
        self.imageGroup = '0'
        self.html = ''
        self.groups = []
        self.imgs = []

    def AddGroup(self, group):
        if not group in self.groups:
            self.groups.append(group)

    def AddImg(self, img):
        if not img in self.imgs:
            self.imgs.append(img)

    def SetSuccess(self, success):
        self.success = success

    def SetImageGroup(self, imgGroup):
        self.imageGroup = imgGroup

    def GenerateHtml(self):

        try:
            ax = ''+self.imageGroup
        except:
            self.imageGroup = str(self.imageGroup)
            
        groupStr = ''
        imgStr = ''

        if len(self.groups) > 0:
            for g in self.groups:
                groupStr += '<a>' + g + ' ✅</a><br>\n'


        if len(self.imgs) > 0:
            for img in self.imgs:
                imgStr += '<img height="100%" src="' + img + '">'

        self.html = """<h1 class=""" + ('"'+self.success.replace('sim', '__sim')+'"') + """>""" + self.adName + """</h1>
        <hr>
        <p>Grupo de imagem: """ + self.imageGroup + """</p>
        <p><b>Imagens utilizadas:</b></p>
        <div class="imgs">
            """ + imgStr + """
        </div>
        <p>Publicado nos grupos: (Total de """ + str(len(self.groups)) + """ grupos sem incluir o grupo inicial)</p>
        <div class="group">
            """ + groupStr + """
        </div>
        <p>Publicado com sucesso? <b class=""" + ('"' + self.success + '"' + """>""" + self.success.replace('nao', 'Não').replace('sim', 'Sim')) + """</b></p>
        <br><br>\n"""


class WholeLog:
    def __init__(self, account, dateTime):
        self.account = account
        self.date = dateTime
        self.html = ''
        self.logs = []

    def AddLog(self, log):
        if not log in self.logs and log != None:
            self.logs.append(log)

    def GenerateHtml(self):

        logsHtml = ''

        for l in self.logs:
            try:
                l.GenerateHtml()
                logsHtml += l.html
            except Exception as e:
                print('Error while generating log: ' + str(e))
                continue

        self.html = """<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório """ + self.date + """</title>
</head>
<script>
    function wclose() {
       window.close();
       window.setTimeout(function() {
           alert('Só é possível fechar pelo navegador do FaceBOT.\\n'
           +'Para outros navegadores, feche a guia.');
       }, 100);
    }

    function save() {
        alert('Só é possível salvar pelo navegador do FaceBOT.\\n'
           +'Para outros navegadores, clique com o botão direito e selecione "Salvar como".');
    }
</script>
<style>

    body {
        font-family: sans-serif;
    }

    .body-center {
        display: inline-block;
        width: 50%;
        min-width: 400px;
        max-width: 700px;
        text-align: left;
    }

    .center {
        text-align: center;
    }

    .group > a {
        display: inline-block;
        text-decoration: underline;
        margin-top: 5px;
        margin-bottom: 5px;
    }

    .group > a:hover {
        background-color: rgb(196, 196, 196);
    }

    .group {
        line-height: 28px;
    }

    .sim {
        color: green;
    }

    .nao {
        color: red;
    }

        .imgs
    {
        width: 100%;
        height: 80px;
        overflow-y: hidden;
        overflow-x: scroll;
        white-space: nowrap;
    }

    img {
        display: inline-block;
        margin: 0px;
        margin-left: 1px;
    }

</style>
<body class="center">

    <br>
    <b>Relatório """ + self.date + """</b>&nbsp;|&nbsp;<a href="javascript:save()" id="savelog">Salvar como</a>&nbsp;
    |&nbsp;<a href="javascript:wclose()" id="closelog">Fechar</a>&nbsp;|&nbsp;Conta usada: <b>""" + self.account + """</b>
    <br><hr><br>

    <div class="body-center">
    
        """ + logsHtml +  """

    </div>

</body>
</html>"""