from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from facebook import *
from ad import *
import os
import io
import sys
from textutil import *
from colorama import *
from selenium.webdriver.firefox.options import Options

init()

VERSION = '1.5'

os.system('cls')
os.system('title FACEBOT')

print('->FACEBOT<-\nVERSION: ' + VERSION + '\n\n') # Allows C# software to read STDOUT

adb = AdBuilder()
# ROOT, FACEBOOK EMAIL, FACEBOOK PASSWORD, A BRICK, GROUPS, RANGE(0-100000000), showBrowser
args = sys.argv[1].replace('"', '').split(',')

root = args[0]
facebookEmail = args[1]
facebookPassword = args[2]
startGroup = args[3]
totalGroups = int(args[4])
ad_range = args[5]
showBrowser = args[6]

options = Options()
if 'false' in showBrowser.lower():
    options.add_argument('--headless')
browser = webdriver.Firefox(options=options)
#browser = webdriver.Firefox()

face = Facebook(browser, Keys)

if (root[len(root)-1] != '\\'):
    root += '\\'

ads = os.listdir(root)

range_split = ad_range.split('-')
range_start = int(range_split[0])
range_end = int(range_split[1])

face.Login(facebookEmail, facebookPassword)
browser.get(startGroup)
time.sleep(10)

totalAd = 0
sucAd = 0

idx=0
for ad in ads:
    if not '_' in ad and (idx >= range_start and idx <= range_end):
        time.sleep(15)

        try:
            adb.InvokeAd(root + ad + '\\', face.DoAd, totalGroups, 'no')
            time.sleep(15)
            SUCCESS('Anúncio realizado com sucesso!')

            browser.refresh()
            sucAd = sucAd + 1
        except:
            ERR('Um erro ocorreu. Próximo ...')
            browser.refresh()

        totalAd = totalAd+1
            
    idx = idx+1

print()
SUCCESS(str(sucAd) + ' de ' + str(totalAd) + ' anúncios foram realizados com sucesso. ('+ str(sucAd) + '/' + str(totalAd) + ')')
print()

browser.close()
time.sleep(2)
browser.quit()
